function D = D_funct(gamma,M)

D = M./(1+(gamma-1)/2*M.^2).^((gamma+1)/(2*(gamma-1)));

end