function M2 = D_iteration_funct(M1,M2_guess,max_iteration,tolerance,gamma,A1,A2,HAP,exponent)

% M1 known, solve for M2
% A1*D1/sqrt(To1)=A2*D2/sqrt(To2)
% D2 = D1*A1/A2*sqrt(1+HAP)

M2 = zeros(1,length(M1));

D1 = D_funct(gamma,M1);
D2 = D1.*A1./A2.*sqrt(1+HAP).^exponent;

for i = 1:length(M1)
    for k = 1:max_iteration             
        D2_guess(k) = D_funct(gamma,M2_guess(k));
        dDdM2_guess(k) = D2_guess(k)/M2_guess(k)*(1-M2_guess(k)^2)/(1+(gamma-1)/2*M2_guess(k)^2);
        M2_new(k) = M2_guess(k)+(D2(i)-D2_guess(k))/dDdM2_guess(k);
        error(k) = abs((M2_guess(k)-M2_new(k))/M2_new(k));
        M2_guess(k+1) = M2_new(k);
        if error(k) <= tolerance
            M2(i) = M2_new(k);
            break
        end
    end
end

end