%% Flight Speed Parametric
clc, clear, close all;

altitude = 55000*0.3048;
% altitude = 10000*0.3048;
% altitude = 0;
gamma=1.4;
[T0,~,P0,~] = atmosisa(altitude);
M0 = linspace(0,2.2,100);

for i = 1:length(M0)
    Po0(i) = P0*(1+(gamma-1)/2*M0(i)^2)^(gamma/(gamma-1));
    [mdot0(i),M2(i),Po2(i)] = inlet_funct_Rev2(M0(i),P0,T0);

    Po_ratio(i) = Po2(i)/Po0(i);
end

figure
% sgtitle({'Effects of Flight Speed (M0) on Real Diffuser Exit Conditions', sprintf('Constant Altitude = %i ft', altitude/0.3048)})

subplot(3,1,1)
hold on
plot(M0,M2)
xlabel('M0')
ylabel('M2')
grid on
hold off

subplot(3,1,2)
hold on
plot(M0,Po_ratio)
xlabel('M0')
ylabel('Po2 / Po0')
grid on
hold off

subplot(3,1,3)
hold on
plot(M0,mdot0)
xlabel('M0')
ylabel('mdot0 (kg/s)')
grid on
hold off

%% Altitude Parametric
clc, clear, close all;

altitude = linspace(0*0.3048,60000*0.3048,100);
altitude_ft = altitude/0.3048;
gamma=1.4;
[T0,~,P0,~] = atmosisa(altitude);
M0 = 1.7;

for i = 1:length(altitude)
    Po0(i) = P0(i)*(1+(gamma-1)/2*M0^2)*(gamma/(gamma-1));
    [mdot0(i),M2(i),Po2(i)] = inlet_funct_Rev2(M0,P0(i),T0(i));

    Po_ratio(i) = Po2(i)/Po0(i);
end

figure
% sgtitle({'Effects of Altitude on Real Diffuser Exit Conditions','Constant M0 = 1.7'})

subplot(3,1,1)
hold on
plot(altitude_ft,M2)
xlabel('Altitude (ft)')
ylabel('M2')
ylim([0,1])
grid on
hold off

subplot(3,1,2)
hold on
plot(altitude_ft,Po_ratio)
xlabel('Altitude (ft)')
ylabel('Po2 / Po0')
grid on
hold off

subplot(3,1,3)
hold on
plot(altitude_ft,mdot0)
xlabel('Altitude (ft)')
ylabel('mdot0 (kg/s)')
grid on
hold off
