clc, clear, close all;

M01 = 0;
M02 = 4;
M03 = 1;
M04 = 1.5;
M05 = 5;
[T01,~,P01,~] = atmosisa(55000*0.3048);
[T02,~,P02,~] = atmosisa(25000*0.3048);
[T03,~,P03,~] = atmosisa(55000*0.3048);
[T04,~,P04,~] = atmosisa(80000*0.3048);

pic = [5,10,15,25,50];
To4 = [1200,1400,1600,1800,2000];
To71 = 1600;
To72 = 1800;
To73 = 2000;
To74 = 2200;

[SFC1,Tsp1,T1] = turbojet_afterburner_funct_Rev1(M01,P01,T01,pic,To4,To71);
%figure_title1 = {'Turbojet with Afterburner','M0 = 0, Altitude = 0 m'};
plot_funct(SFC1,Tsp1,pic,To4)

[SFC2,Tsp2,T2] = turbojet_afterburner_funct_Rev1(M02,P01,T01,pic,To4,To71);
%figure_title2 = {'Turbojet with Afterburner','M0 = 0.5, Altitude = 0 m'};
plot_funct(SFC2,Tsp2,pic,To4)
