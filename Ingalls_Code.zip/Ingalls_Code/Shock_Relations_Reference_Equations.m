clc, clear, close all;

%% Forward Across Normal Shock
gamma = 1.4;

M1 = 2.64;
M2 = sqrt(((gamma-1)*M1^2+2)/(2*gamma*M1^2-(gamma-1)))

%% Backward Across Normal Shock
gamma = 1.4;

M2 = 0.5;
M1 = sqrt(((gamma-1)*M2^2+2)/(2*gamma*M2^2-(gamma-1)))

%% Forward Across Oblique Shock
clc,clear,close all;
gamma = 1.4;

delta = 2; % physical geometry angle
M1 = 1.3;

f = @(epsilon) 2*cotd(epsilon)/tand(delta)*((M1^2*sind(epsilon).^2-1)/(M1^2*(gamma+cosd(2*epsilon))+2))-1;
epsilon_guess = 40;
epsilon = fzero(f,epsilon_guess) % shock angle

MN1 = M1*sind(epsilon);
MN2 = sqrt(((gamma-1)*MN1^2+2)/(2*gamma*MN1^2-(gamma-1)));
M2 = MN2/sind(epsilon-delta)

%% Backward Across Oblique Shock
gamma = 1.4;

delta = 10; % physical geometry angle
epsilon = atand((tand(delta)*(((gamma+1)*M1^2)/(2*(MN1^2-1))-1))^(-1)); % shock angle


M2 = 1.1804;
MN2 = M2*sind(epsilon-delta);
MN1 = sqrt(((gamma-1)*MN2^2+2)/(2*gamma*MN2^2-(gamma-1)));
M1 = MN1/sind(epsilon)
