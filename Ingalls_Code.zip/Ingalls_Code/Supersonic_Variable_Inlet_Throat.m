% Determines inlet throat area increase needed to swallow a shock for
% supersonic flight
clc, clear, close all;

gamma = 1.4;
M0 = 1.5;

% Normal Shock Relations
A3star_A0star = (((gamma+1)/2*M0^2)/(1+(gamma-1)/2*M0^2))^(-gamma/(gamma-1))*(2*gamma/(gamma+1)*M0^2+-(gamma-1)/(gamma+1))^(-1/(1-gamma));

% Throat Area Increase = At_shock/At_noshock = (Ai/A0star)/(Ai/A3star) =
% A3star/A0star
A2_increase_factor = A3star_A0star