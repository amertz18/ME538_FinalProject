function [mdot0,M5,Po5,To5] = inlet_funct_Rev1(M0,P0,T0)

gamma = 1.4;

[Tsls,~,Psls,~] = atmosisa(0);
A1 = 7; % inlet area based on approx. turbofan/supersonic inlets in industry
A1A4_ratio = 1/1.7*((1+(gamma-1)/2*1.7^2)/(1+(gamma-1)/2))^((gamma+1)/(2*(gamma-1))); % ratio of inlet to throat area determined by supersonic start condition
A4A5_ratio = 1/1.85; % ratio of throat to divergenging section exit area

A4 = A1/A1A4_ratio; % throat area
A5 = A4/A4A5_ratio; % diverging section exit area

if M0 >= 1.7
    % Supersonic Case
    % Case 1
    % disp('Case 1')

    etad = 0.97;
    gamma = 1.4;
    R = 287;
    max_iteration = 1000;
    tolerance = 1E-10;
    
    delta = 2; % physical geometry angle
    
    Po0 = P0*(1+(gamma-1)/2*M0^2)^(gamma/(gamma-1));
    To0 = T0*(1+(gamma-1)/2*M0^2);
    
    M1 = M0;
    P1 = P0;
    T1 = T0;
    Po1 = P0*(1+etad*(gamma-1)/2*M0^2)^(gamma/(gamma-1));
    To1 = To0;
    
    mdot0 = P1/(R*T1)*A1*(M1*sqrt(gamma*R*T1));
    
    M_upstream_shock_guess = 1.5;
    M_upstream_shock = D_iteration_funct(M1,M_upstream_shock_guess,max_iteration,tolerance,gamma,A1,A4,0,1)+0.1;
    M4 = sqrt(((gamma-1)*M_upstream_shock^2+2)/(2*gamma*M_upstream_shock^2-(gamma-1)));
    Po4 = Po1*((gamma+1)/2*M_upstream_shock^2/(1+(gamma-1)/2*M_upstream_shock^2))^(gamma/(gamma-1))*(2*gamma*M_upstream_shock^2/(gamma+1)-(gamma-1)/(gamma+1))^(1/(1-gamma));
    
    % Diverging Section After Shock Results in M5 < 0.5
    % CoM (A4*D4 = A5*D5)
    M5_guess = 0.2;
    M5 = D_iteration_funct(M4,M5_guess,max_iteration,tolerance,gamma,A4,A5,0,1);
    Po5 = Po4;
    To5 = To0;
elseif M0 < 1.7 && M0 >= 1
    % Shock in front of inlet
    etad = 0.97;
    gamma = 1.4;
    R = 287;
    max_iteration = 1000;
    tolerance = 1E-10;
    
    delta = 2; % physical geometry angle
    
    Po0 = P0*(1+(gamma-1)/2*M0^2)^(gamma/(gamma-1));
    To0 = T0*(1+(gamma-1)/2*M0^2);
    
    M1 = sqrt(((gamma-1)*M0^2+2)/(2*gamma*M0^2-(gamma-1)));
    P1 = P0;
    T1 = T0;
    Po1 = Po0*((gamma+1)/2*M0^2/(1+(gamma-1)/2*M0^2))^(gamma/(gamma-1))*(2*gamma*M0^2/(gamma+1)-(gamma-1)/(gamma+1))^(1/(1-gamma));
    P1 = Po1*(1+(gamma-1)/2*M1^2)^(-gamma/(gamma-1));
    To1 = To0;
    
    mdot0 = P1/(R*T1)*A1*(M1*sqrt(gamma*R*T1));
       
    % Diverging Section After Shock Results in M5 < 0.5
    % CoM (A4*D4 = A5*D5)
    M5_guess = 0.2;
    M5 = D_iteration_funct(M1,M5_guess,max_iteration,tolerance,gamma,A1,A5,0,1);
    Po5 = P1*(1+etad*(gamma-1)/2*M1^2)^(gamma/(gamma-1));
    To5 = To0;
elseif M0 < 1
    % Subsonic Case (M > 0.5)
    % Case 2
    % disp('Case 2')

    R = 287;
    max_iteration = 1000;
    tolerance = 1E-10;
    gamma = 1.4;

    % To modify using real values
    etad = 0.97;
    mdot0_sea_level = 275;

    Po0 = P0*(1+(gamma-1)/2*M0^2)^(gamma/(gamma-1));
    To0 = T0*(1+(gamma-1)/2*M0^2);

    mdot_from_corrected = mdot0_sea_level/sqrt(To0/Tsls)*(Po0/Psls);

    % Assumption: isothermal air entry in the inlet
    T1 = T0;
    
    % Solve for P1 at static condition using Bernoulli's equation
    p1s = roots([-2*(A1/(R*T1))^2, 2*P0*(A1/(R*T1))^2, 0, -mdot_from_corrected^2]);

    if ~(all(isreal(p1s)))
        error("Pressure too low at the given altitude to obtain the desired mass flow")
    end
    % Keep the highest solution, if several P1 work
    P1 = max(p1s);
    
    % Compute u1 and M1 for that case
    u1 = sqrt(2*(P0-P1));
    M1 = u1/sqrt(gamma*R*T1);
    
    % Assume M1 is the same as in the static M0 = 0 case
    M1_assumpt = M1;
    
    % Compute A0 from the free-stream Mach number
    A0 = A1.*D_funct(gamma, M1_assumpt)./D_funct(gamma, M0);

    if A0 < A1
        A0 = A1;

        M1_guess = 0.2;
        M1 = D_iteration_funct(M0,M1_guess,max_iteration,tolerance,gamma,A0,A1,0,1);
    end
    
    % Compute the mass flow with those conditions
    mdot0 = P0/(R*T0)*(sqrt(gamma*R*T0))*(A0.*M0);
    if M0 < 1 && M0 >= 0.5
        M4 = sqrt(((gamma-1)*1.1^2+2)/(2*gamma*1.1^2-(gamma-1)));
        Po4 = Po0*((gamma+1)/2*1.1^2/(1+(gamma-1)/2*1.1^2))^(gamma/(gamma-1))*(2*gamma*1.1^2/(gamma+1)-(gamma-1)/(gamma+1))^(1/(1-gamma));
        P4 = Po4*(1+(gamma-1)/2*M4^2)^(-gamma/(gamma-1));
        Po5 = P4*(1+etad*(gamma-1)/2*M4^2)^(gamma/(gamma-1));
        % Diverging Section After Shock Results in M5 < 0.5
        % CoM (A4*D4 = A5*D5)
        M5_guess = 0.2;
        M5 = D_iteration_funct(M1,M5_guess,max_iteration,tolerance,gamma,A1,A5,0,1);
    elseif M0 < 0.5 && M0 >= 0
        Po5 = P0*(1+etad*(gamma-1)/2*M0^2)^(gamma/(gamma-1));
        % Diverging Section After Shock Results in M5 < 0.5
        % CoM (A4*D4 = A5*D5)
        M5_guess = 0.2;
        M5 = D_iteration_funct(M1,M5_guess,max_iteration,tolerance,gamma,A1,A5,0,1);
    To5 = To0;
    end
end