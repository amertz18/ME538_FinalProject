function plot_funct(SFC,Tsp,pic,To4)

figure
%sgtitle(figure_title)

subplot(2,2,1)
hold on
for i = 1:length(pic)
    plot(Tsp(i,:),SFC(i,:))
end
for j = 1:length(To4)
    plot(Tsp(:,j),SFC(:,j),'--')
end
%legend('To4=1200K','To4=1400K','To4=1600K','To4=1800K','To4=2000K','pic=5','pic=10','pic=15','pic=25','pic=50','Location','northeast')
xlabel('Specific Thrust, Tsp (N-s/kg)')
ylabel('SFC (kg/hr-N)')
title('To7 = 1600 K')
grid on
hold off

subplot(2,2,2)
hold on
for i = 1:length(pic)
    plot(Tsp(i,:),SFC(i,:))
end
for j = 1:length(To4)
    plot(Tsp(:,j),SFC(:,j),'--')
end
%legend('To4=1200K','To4=1400K','To4=1600K','To4=1800K','To4=2000K','pic=5','pic=10','pic=15','pic=25','pic=50','Location','northeast')
xlabel('Specific Thrust, Tsp (N-s/kg)')
ylabel('SFC (kg/hr-N)')
title('To7 = 180 K')
grid on
hold off

subplot(2,2,3)
hold on
for i = 1:length(pic)
    plot(Tsp(i,:),SFC(i,:))
end
for j = 1:length(To4)
    plot(Tsp(:,j),SFC(:,j),'--')
end
%legend('To4=1200K','To4=1400K','To4=1600K','To4=1800K','To4=2000K','pic=5','pic=10','pic=15','pic=25','pic=50','Location','northeast')
xlabel('Specific Thrust, Tsp (N-s/kg)')
ylabel('SFC (kg/hr-N)')
title('To7 = 2000 K')
grid on
hold off

subplot(2,2,4)
hold on
for i = 1:length(pic)
    plot(Tsp(i,:),SFC(i,:))
end
for j = 1:length(To4)
    plot(Tsp(:,j),SFC(:,j),'--')
end
%legend('To4=1200K','To4=1400K','To4=1600K','To4=1800K','To4=2000K','pic=5','pic=10','pic=15','pic=25','pic=50','Location','northeast')
xlabel('Specific Thrust, Tsp (N-s/kg)')
ylabel('SFC (kg/hr-N)')
title('To7 = 2200 K')
grid on
hold off

end