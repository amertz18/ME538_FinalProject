function [SFC,Tsp,T] = turbojet_afterburner_funct_Rev1(M0,P0,T0,pic,To4,To7)

%% Problem B

%% SLS Conditions

% Gas Properties
Ru = 8314.5; % (J/kmol-K)
MW = 28.97; % air (g/mol)
R = Ru/MW; % (J/kg-K)
gamma14 = 7/5; % air
gamma49 = 4/3;
cp14 = R*gamma14/(gamma14-1); % air (J/kg-K)
cp49 = R*gamma49/(gamma49-1);

% Jet-A
dHB = 43000000; % Jet-A (J/kg-K)

% Sea Level Static Givens
T = 25000 * 4.4482; % SLS thrust (N)
Psls = 101300; % SLS (Pa)
Tsls = 15 + 273.15; % SLS (K)

% Operating Conditions
M0_sls = 0;
P0_sls = 101300; % SLS (Pa)
T0_sls = 15 + 273.15; % SLS (K)

counter = 1;
for j = 1:length(To4)
    for i = 1:length(pic)
        
        To0 = T0_sls.*(1+(gamma14-1)./2.*M0_sls.^2);
        Po0 = P0_sls.*(1+(gamma14-1)./2.*M0_sls.^2).^(gamma14./(gamma14-1));
        a0 = sqrt(gamma14.*R.*T0_sls);
        u0 = M0_sls.*a0;
        
        To1 = To0;
        Po1 = Po0;
        
        To2 = To1;
        Po2 = Po1;
        
        To3 = To2.*pic(i).^((gamma14-1)./gamma14);
        Po3 = Po2.*pic(i);
        
        fb = (To4(j)-To3).*cp14./dHB;
        Po4 = Po3;
        
        To5 = To4(j)-cp14/cp49*(To3-To2)./(1+fb);
        Po5 = Po4.*(To5./To4(j)).^(gamma49./(gamma49-1));
        
        fab = ((1+fb)*(cp49*To5-cp49*To7))/(cp49*To7-dHB);
        Po7 = Po5;

        To9 = To7;
        Po9 = Po7;
        P9 = P0_sls;
        u9 = sqrt(2.*cp49.*To9.*(1-(P9./Po9).^((gamma49-1)./gamma49)));
        
        % T(i,j) = mdot0.*((1+fb+fab).*u9-u0);
        
        mdot0 = T./((1+fb+fab).*u9-u0);
        mdotfb = mdot0.*fb;
        mdotfab = mdot0.*fab;
        
        if fb < 0
            mdotc(i,j) = NaN;
            Tsp(i,j) = NaN;
            SFC(i,j) = NaN;
        else
            mdotc(i,j) = mdot0./((Po1./Psls)./sqrt(To1./Tsls));
            Tsp(i,j) = (1+fb+fab).*u9-u0; % (N-s/kg)
            SFC(i,j) = (fb+fab)./Tsp(i,j).*3600; % (kg/hr-N)
        end

        M0_sls_all(counter,1) = M0_sls;
        P0_sls_all(counter,1) = P0_sls;
        T0_sls_all(counter,1) = T0_sls;
        u0_all(counter,1) = u0;
        u9_all(counter,1) = u9;
        fb_all(counter,1) = fb;
        fab_all(counter,1) = fab;
        pic_all(counter,1) = pic(i);
        To4_all(counter,1) = To4(j);
        To5_all(counter,1) = To5;
        To7_all(counter,1) = To7;
        SFC_all(counter,1) = SFC(i,j);
        Tsp_all(counter,1) = Tsp(i,j);
        T_all(counter,1) = T;
        counter = counter + 1;

    end
end

table1 = table(M0_sls_all,P0_sls_all,T0_sls_all,u0_all,u9_all,fb_all,fab_all,pic_all,To4_all,To5_all,To7_all,SFC_all,Tsp_all,T_all,'VariableNames',{'M0_sls','P0_sls','T0_sls','u0','u9','fb','fab','pic','To4','To5','To7','SFC','Tsp','T'});


%% Non-SLS Conditions

clearvars -except M0 P0 T0 pic To4 To7 mdotc;

% Gas Properties
Ru = 8314.5; % (J/kmol-K)
MW = 28.97; % air (g/mol)
R = Ru/MW; % (J/kg-K)
gamma = 7/5; % air
gamma14 = 7/5; % air
gamma49 = 4/3;
cp14 = R*gamma14/(gamma14-1); % air (J/kg-K)
cp49 = R*gamma49/(gamma49-1);

% Jet-A
dHB = 43000000; % Jet-A (J/kg-K)

% Sea Level Static Givens
T = 25000 * 4.4482; % SLS thrust (N)
Psls = 101300; % SLS (Pa)
Tsls = 15 + 273.15; % SLS (K)

counter = 1;
for j = 1:length(To4)
    for i = 1:length(pic)
        
        To0 = T0.*(1+(gamma14-1)./2.*M0.^2);
        Po0 = P0.*(1+(gamma14-1)./2.*M0.^2).^(gamma14./(gamma14-1));
        a0 = sqrt(gamma14.*R.*T0);
        u0 = M0.*a0;
        
        To1 = To0;
        Po1 = Po0;
        
        To2 = To1;
        Po2 = Po1;
        
        To3 = To2.*pic(i).^((gamma14-1)./gamma14);
        Po3 = Po2.*pic(i);
        
        fb = (To4(j)-To3).*cp14./dHB;
        Po4 = Po3;
        
        To5 = To4(j)-cp14/cp49*(To3-To2)./(1+fb);
        Po5 = Po4.*(To5./To4(j)).^(gamma49./(gamma49-1));
        
        fab = ((1+fb)*(cp49*To5-cp49*To7))/(cp49*To7-dHB);
        Po7 = Po5;

        To9 = To7;
        Po9 = Po7;
        P9 = P0;
        u9 = sqrt(2.*cp49.*To9.*(1-(P9./Po9).^((gamma49-1)./gamma49)));
        
        mdot0 = mdotc(i,j).*(Po1./Psls)./sqrt(To1./Tsls);
        mdotfb = mdot0.*fb;
        mdotfab = mdot0.*fab;
        
        if fb < 0
            T(i,j) = NaN;
            Tsp(i,j) = NaN;
            SFC(i,j) = NaN;
        else
            T(i,j) = mdot0.*((1+fb+fab).*u9-u0);
            Tsp(i,j) = (1+fb+fab).*u9-u0; % (N-s/kg)
            SFC(i,j) = (fb+fab)./Tsp(i,j).*3600; % (kg/hr-N)
        end
     
        M0_all(counter,1) = M0;
        P0_all(counter,1) = P0;
        T0_all(counter,1) = T0;
        u0_all(counter,1) = u0;
        u9_all(counter,1) = u9;
        fb_all(counter,1) = fb;
        fab_all(counter,1) = fab;
        pic_all(counter,1) = pic(i);
        To4_all(counter,1) = To4(j);
        To5_all(counter,1) = To5;
        To7_all(counter,1) = To7;
        SFC_all(counter,1) = SFC(i,j);
        Tsp_all(counter,1) = Tsp(i,j);
        T_all(counter,1) = T(i,j);
        counter = counter + 1;

    end
end

table1 = table(M0_all,P0_all,T0_all,u0_all,u9_all,fb_all,fab_all,pic_all,To4_all,To5_all,To7_all,SFC_all,Tsp_all,T_all,'VariableNames',{'M0','P0','T0','u0','u9','fb','fab','pic','To4','To5','To7','SFC','Tsp','T'});

end

